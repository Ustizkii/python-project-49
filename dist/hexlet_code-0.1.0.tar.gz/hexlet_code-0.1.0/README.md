### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ustizkii/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ustizkii/python-project-49/actions)

<a href="https://codeclimate.com/github/Ustizkii/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/227304f77fc67dc0c265/maintainability" /></a>

### asciinema brain-even recording
https://asciinema.org/a/uZzUeRwPvj7ZA07W7nuEfrV0u

### asciinema brain-calc recording
https://asciinema.org/connect/3b0e1b29-292f-4b05-8657-cef9eda7ba93

### asciinema brain-nod recording
https://asciinema.org/a/cyPqjeTu1p1bltt7JUrTJkIVD

### asciinema brain-prog recording
https://asciinema.org/a/GVvofgQoNWKguZgl0bL3DSUZI

### asciinema brain-prime recording
https://asciinema.org/a/pEQdr6OcUwCFUqkazIIrcSCTx