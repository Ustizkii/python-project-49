### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ustizkii/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ustizkii/python-project-49/actions)

<a href="https://codeclimate.com/github/Ustizkii/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/227304f77fc67dc0c265/maintainability" /></a>

### asciinema recording
https://asciinema.org/a/mllQ3mvCN2RsVGhJvWpqPt2U3